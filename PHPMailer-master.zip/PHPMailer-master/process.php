<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // Use __DIR__ to get the directory of the current file
    require __DIR__ . '/PHPMailer/src/Exception.php';
    require __DIR__ . '/PHPMailer/src/PHPMailer.php';
    require __DIR__ . '/PHPMailer/src/SMTP.php';

    // Create a new PHPMailer instance
    $mail = new PHPMailer();

    // Set the recipient email address
    $mail->addAddress("shasars9@gmail.com");

    // Set the subject of the email
    $mail->Subject = "New Form Submission";

    // Compose the email message
    $mail->Body = "Name: $name\nEmail: $email\nMessage:\n$message";

    // Set additional headers
    $mail->setFrom($email);


    // Send the email
    if ($mail->send()) {
        echo "Thank you for your submission!";
    } else {
        echo "Oops! Something went wrong and we couldn't send your message.";
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
} else {
    // If the form is not submitted, redirect to the form page
    header("Location: index.html");
    exit();
}
?>
